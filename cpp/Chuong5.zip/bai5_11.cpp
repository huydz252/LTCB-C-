#include <iostream>
using namespace std;
int main (){

	int n,rem,reverse_n,h;
	
	cout<<"Input n: " ;
	cin>>n;
	while (n<=0) {
		cout<<"nhap n (n>0) : ";
		cin>>n;
	}
	
	while(n>=1){
       rem = n % 10;
       reverse_n = reverse_n * 10 + rem;
       n = n / 10;
    }
    while (reverse_n>0) {
    	h=reverse_n%10;
    	reverse_n=reverse_n/10;
    	if (h == 0) cout<<"zero "; 
    	if (h == 1) cout<<"one ";
    	if (h == 2) cout<<"two ";
    	if (h == 3) cout<<"three ";
    	if (h == 4) cout<<"four ";
    	if (h == 5) cout<<"five ";
    	if (h == 6) cout<<"six ";
    	if (h == 7) cout<<"seven ";
    	if (h == 8) cout<<"eight ";
    	if (h == 9) cout<<"nine ";
	}
}
