#include <iostream>
#include <math.h>;
using namespace std;

int maxLOD(int n) {
	for(int i = n ; i >= 1 ; i--) {
		if (n%i == 0 and i%2 == 1) return i;
	}
	return 0;
}

int main (){
	int n;
	
	cout<<"Input postive number a: ";
	cin>>n;
	while (n<0) {
		cout<<"Input postive number n (n>0) : ";
		cin>>n;
	}
	if (maxLOD(n) == 0) cout<<"N" ;
	else
	cout<<"the largest odd divisor is " <<maxLOD(n);
	
	
}
