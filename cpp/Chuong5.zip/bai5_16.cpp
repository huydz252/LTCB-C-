#include <iostream>
#include <math.h>;
using namespace std;
int main (){ 
	
	int n,rem,reverse_n;
	
	cout<<"Input n: " ;
	cin>>n;
	while (n<0) {
		cout<<"nhap n (n>0) : ";
		cin>>n;
	}
	//dao nguoc n
	while(n>=1){
       rem = n % 10;
       reverse_n = reverse_n * 10 + rem;
       n = n / 10;
    }
    int a,b=0;
	while (reverse_n != 0) {
		a = reverse_n%10;
		reverse_n = reverse_n/10;
		if (a%2 == 1) {
			cout<<a;
			b += 1;
		}
	}
	if (b == 0) cout <<"N" ;
}
