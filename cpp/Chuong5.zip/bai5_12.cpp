#include <iostream>
using namespace std;
int main (){
	
	int n,s1,s2,s3;
	
	cout<<"Nhap n: ";
	cin>>n;
	while (n<=0) {
		cout<<"nhap n (n>0) : ";
		cin>>n;
	}
	
	for (int i = 0; i <= n ; i++) {
		if (i<=1) {
			s3 = i;
		}
		else {
			s3=s1+s2;
			s1=s2;
			s2=s3;
		}
		cout<<s3 <<" ";
	} 
	
	
}
