#include <iostream>
#include <math.h>;
using namespace std;
int main (){

	int m, n, temp, rem,  armstr, s=0;
	
	cout<<"nhap m (m>0) : ";
	cin>>m;
	while (m<0) {
		cout<<"nhap m (m>0) : ";
		cin>>m;
	}
	
	cout<<"nhap n (n>m) : ";
	cin>>n;
	while (n<m) {
		cout<<"nhap n (n>m) : ";
		cin>>m;
	}

	for (int i = m+1 ; i < n ; i++){
	
		temp = i;
		armstr = 0;
	
		while (temp != 0) {
			rem = temp % 10;
			armstr = armstr + rem*rem*rem;
			temp = temp / 10;
		}
		
		if (i == armstr) {
			if (s == 0)	{
				cout<<"cac so armstrong trong khoang " <<m <<" den " <<n <<" la: " ;
			}
		cout<<i << " ";
		s++;	
		}
    }
	
	if (s == 0) {
		cout<<"khong co so armstrong nao trong khoang " <<m <<" den " <<n <<"!" ;
	}
	
}
