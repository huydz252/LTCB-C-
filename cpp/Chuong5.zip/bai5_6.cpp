#include <iostream>
using namespace std;
int main () {
	
	int n;
	cout<<"nhap so tu nhien n: ";
	cin>>n;
	
	if (n==0) cout<<"0 1" ; 
	if (n>0){
		for (int i = n ; i>=1 ; i--)
		    cout<<i <<" ";
	}
	if (n<0){
		for (int i = n ; i<=1 ; i++)
		    cout<<i <<" ";
	}
	
}
