#include <iostream>
using namespace std;
int main () {
	
	int n,sum;
	
	cout<<"nhap n: ";
	cin>>n;
	
	while (n<=0) {
		cout<<"nhap n (>0): ";
		cin>>n;		
	}
	
	sum=0;
	for (int i = 1; i<= n; i++){
		if(i%2==0){
			sum+=i;
		}
	}
	
	cout<<"tong cac so chan tu 1 den " <<n <<" la: " <<sum;
}
