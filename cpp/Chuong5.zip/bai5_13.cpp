#include <iostream>
using namespace std;
int main (){
	
	int m,n;
	
	cout<<"Nhap m: ";
	cin>>m;
	while (m<=0) {
		cout<<"nhap m (m>0) : ";
		cin>>m;
	}
	cout<<"Nhap n: ";
	cin>>n;
	while (n<=0) {
		cout<<"nhap n (n>0) : ";
		cin>>n;
	}
	
	cout<<"\n";
	for (int i = 1 ; i <= n ; i++) {
		for (int i = 1 ; i <= m ; i++) {
		cout<<"* ";
		}
	cout<<"\n";
	}
}
