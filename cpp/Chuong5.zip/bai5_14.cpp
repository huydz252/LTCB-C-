#include <iostream>
#include <math.h>
using namespace std;
int choice;
//ARMSTRONG NUMBER
void checkArmstrong (int a) {
	cout<<"CHECK ARMSTRONG NUMBER !";
    int num,copy_of_num,sum=0,rem;
    cout<<endl<<"input integer: ";
    cin>>num;
    copy_of_num = num;
    while (num != 0)
   {
      rem = num % 10;
      sum = sum + (rem*rem*rem);
      num = num / 10;
   }
   if(copy_of_num == sum)
      cout<<copy_of_num<<" is the Armstrong number ";
   else
      cout<<copy_of_num<<" is not the Armstrong number ";
}
//PRIME NUMBER
void checkPrime(int b) {
	cout<<"CHECK PRIME NUMBER ! \n";
	cout<<"Input integer: ";
	cin>>b;
	
	while (b<=0) {
		cout<<"Input a postive integer:  ";
		cin>>b;
	}
	int s;
	if (b==1) cout<<b <<" is not the prime number!";
	else {
	if(b==2) cout<<b <<" is the prime number!";	
		else {
			s=0;
			for (int i = 1 ; i <= b ; i++) {
				if (b%i == 0)
					s +=1;	
			}
			if (s != 2) cout<<b <<" is not an prime number!";
			else cout<<b <<" is an prime number!";	
		}
	}
}



int main (){ 
	int a,b,c;
	
		cout<<"***********************\n" ;
		cout<<"*        MENU         *\n" ;
		cout<<"*     1.Armstrong     *\n" ;
		cout<<"*     2.Prime         *\n" ;
		cout<<"*     3.Finish        *\n" ;
		cout<<"***********************\n" ;
	
		cout<<"What are your options? :" ;
		cin>>choice;
		
		if (choice != 1 and choice != 2 and choice != 3) cout <<"ERROR \n";
		if (choice == 1) {
			checkArmstrong(a);		
		}if (choice == 2) {
			checkPrime(b);		
		}	
	
	if (choice == 3) {
		
		char input;
		
		cout<<"input your choice(c/k): ";
		cin>>input;
		
		if (input == 'c') cout<<"see you again!";
		else if (input == 'k') {	
				cout<<"***********************\n" ;
				cout<<"*        MENU         *\n" ;
				cout<<"*     1.Armstrong     *\n" ;
				cout<<"*     2.Prime         *\n" ;
				cout<<"*     3.Finish        *\n" ;
				cout<<"***********************\n" ;
	
				cout<<"What are your options? :" ;
				cin>>choice;
				if (choice != 1 and choice != 2 and choice != 3) cout <<"ERROR \n";
	
				if (choice == 1) {
					checkArmstrong(a);		
				}if (choice == 2) {
					checkPrime(b);		
				}
	
		}
	}
}






