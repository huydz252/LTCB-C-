#include <iostream>
//#include <stdio.h>
using namespace std;
int main(){
  
	int num,rem,reverse_num=0;
   
	cout<<"Nhap n: ";
	cin>>num;
  
    while(num>=1){
       rem = num % 10;
       reverse_num = reverse_num * 10 + rem;
       num = num / 10;
    }
	
	if(num = reverse_num){
		cout<<"day la so Palindrome!";
	}
	else cout<<"day k phai la so Palindrome!";
 
 }  
