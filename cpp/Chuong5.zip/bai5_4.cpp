#include <iostream>
using namespace std;
int main () {
	
	int n,u;
	
	cout<<"nhap so nguyen duong n: " ;
	cin>>n;
	while (n<=0) {
		cout<<"nhap lai so nguyen duong n: ";
		cin>>n;
	}
	
	u=0;
	for (int i=1 ; i<=n ; i++){
        u+=i*i;
	}
	
	cout<<"gia tri can tim: " <<u;
		
}
