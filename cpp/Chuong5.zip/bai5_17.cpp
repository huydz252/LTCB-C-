#include <iostream>
#include <math.h>;
using namespace std;
int main (){
	
	int n,sum=0,i=0,t;
	
	cout<<"Input n: " ;
	cin>>n;
	if (n<=0) cout <<"N";
	else{
		while (sum <= n) {
			sum = sum + i;
			i = i+1 ;
			t=i-2;
		}
		cout<<"k is " <<t;	
		}
}

