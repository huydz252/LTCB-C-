#include <iostream>
using namespace std;
int main(int argc, char** argv) {
  
    for (int i = 48 ; i <= 127 ; i++){
    	cout<<i <<"  " <<(char)i <<endl;
    }
}
