#include <iostream>
using namespace std;
int main (){
	int x,y;
	cout<<"nhap x: ";
	cin>>x;
	cout<<"nhap y: ";
	cin>>y;
	cout<<"p = x*y = "<<x*y <<endl;
	cout<<"s = x+y = "<<x+y <<endl;
	cout<<"q = s2+p(sx)*(p+y) =" <<(x+y)*2+(x*y)*((x+y)*x)*(x*y+y);
	
}
