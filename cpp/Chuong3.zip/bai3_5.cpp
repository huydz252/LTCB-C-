#include <iostream>
using namespace std;
int main () {
 	float v0, a, t;
 	cout<<"nhap van toc ban dau(m/s): ";
 	cin>>v0;
 	while (v0 <= 0) {
	    cout<<"nhap van toc ban dau (v0 > 0): ";
 	    cin>>v0;
	}
 	
 	cout<<"nhap gia toc(m/s^2): " ;
 	cin>>a;
 	
	cout<<"nhap thoi gian di chuyen(s): ";
 	cin>>t;
 	while (t<=0) {
 		cout<<"nhap thoi gian di chuyen(t>0): " ;
 		cin>>t;
 	}
 	
	 cout<<"van toc cuoi cung la: " <<v0+a*t <<"m/s" ;
 
 }
 	
