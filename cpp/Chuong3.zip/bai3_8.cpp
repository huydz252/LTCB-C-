#include <iostream>
#include <math.h>
using namespace std;
int main (){
	int x;
	cout<<"nhap so do goc : " ;
	cin>>x;
	cout<<"sin"<<x<<" = " <<sin(M_PI*x/180) <<endl;
	cout<<"cos"<<x<<" = " <<cos(M_PI*x/180) <<endl;
	cout<<"tan"<<x<<" = " <<tan(M_PI*x/180) <<endl;
	cout<<"cot"<<x<<" = " <<1/(tan(M_PI*x/180)) <<endl;
	
}
