#include <iostream>
using namespace std;
int main (){
	int x,y;
	cout<<"nhap x: ";
	cin>>x;
	cout<<"nhap y: ";
	cin>>y;
	
	cout <<"Gtri x   Gtri y   Bieu Thuc   Ket Qua" <<endl;
	cout <<x<<"|      "<<y<<"|       "<<"A=y+3" <<"       "<<"|A="<<y+3 <<endl;
	cout <<x<<"|      "<<y<<"|       "<<"B=y-2" <<"       "<<"|B="<<y-2 <<endl;
	cout <<x<<"|      "<<y<<"|       "<<"C=y*5" <<"       "<<"|C="<<y*5 <<endl;
	cout <<x<<"|      "<<y<<"|       "<<"D=x/y" <<"       "<<"|D="<<x/y <<endl;
	cout <<x<<"|      "<<y<<"|       "<<"E=x%y" <<"       "<<"|E="<<x%y <<endl;
}
