#include <iostream>
#include <cstring>
using namespace std;
 int main () {
	char str[100];
	cout<<"nhap: " ;
	gets(str);
	int length;
	length = strlen(str);
	cout<<"do dai chuoi la: " <<length ;
	
}
