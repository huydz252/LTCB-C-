#include <iostream>
using namespace std;
int main (){
    int kt1,kt2,kt3,gk,ck;
    cout<<"==========Diem kiem tra==========" <<endl;
    cout<<"nhap diem kiem tra 1: " ;
    cin>>kt1;
    cout<<"nhap diem kiem tra 2: " ;
    cin>>kt2;
    cout<<"nhap diem kiem tra 3: " ;
    cin>>kt3;
    cout<<"==========Diem thi giua ky==========" <<endl;
    cout<<"nhap diem thi giua ki: " ;
    cin>>gk;
    cout<<"==========Diem thi cuoi ky==========" <<endl ;
    cout<<"nhap diem thi cuoi ki: " ;
    cin>>ck;
    cout<<"tong diem kiem tra: " <<kt1+kt2+kt3 <<endl;
    cout<<"diem thi giua ki: " <<gk <<endl;
    cout<<"diem thi cuoi ki: " <<ck <<endl;
}
