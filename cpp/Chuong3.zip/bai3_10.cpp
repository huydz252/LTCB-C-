#include <iostream>
using namespace std;
int main (){
	int x,y;
	cout<<"nhap so thu nhat: ";
	cin>>x;
	while(x<10 | x>99){
		cout<<"nhap so thu nhat(so co 2 chu so): ";
	cin>>x;
	}
	cout<<"nhap so thu hai: ";
	cin>>y;
	while(y<10 | y>99){
		cout<<"nhap so thu nhat(so co 2 chu so): ";
	cin>>y;
	}
	cout<<"tong 2 so do la: " <<x+y ;
}
