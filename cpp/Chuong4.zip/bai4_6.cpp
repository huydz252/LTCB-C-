#include <iostream>
#include <math.h>;
using namespace std;
int main () {
	
	float a,b,c,denta,x1,x2;
    	
	cout << "nhap he so a: ";
	cin >>a;
	while (a == 0) {
	    cout<<"he so a phai khac 0, vui long nhap lai:  " ;	 
		cin >> a;  	    
	}    	
	cout << "nhap he so b: ";
	cin >>b;
	cout << "nhap he so c: ";
	cin >>c;
	
	denta = b*b - 4*a*c ;
	
	if (denta < 0) cout<<"phuong trinh vo nghiem" ;
	if (denta = 0) cout<<"phuong trinh co 2 nghiem kep: " <<-b/(2*a) ;	
	if (denta >0){
	x1=(-b + sqrt(denta))/(2*a);
	x2=(-b - sqrt(denta))/(2*a); 
	cout <<"nghiem thu nhat la: " << x1 <<endl ;
	cout <<"nghiem thu hai la: " << x2 <<endl ;
    }
}

