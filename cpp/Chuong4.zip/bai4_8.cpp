#include <iostream>
using namespace std;
int main (){
	
	float quiz, mid_term, final_score,GPA;
	
	cout<<"input point quiz (0-100): " ;
	cin>>quiz;
	while (quiz <0 || quiz >100){
		cout<<"1-100 ok?: " ;
		cin>>quiz;
	}
	
	cout<<"input point mid term (0-100): " ;
	cin>>mid_term;
	while (mid_term <0 || mid_term >100){
		cout<<"1-100 ok? : " ;
		cin>>mid_term;
	}
	
	cout<<"input point final_score (0-100): " ;
	cin>>final_score;
	while (final_score <0 || final_score >100){
		cout<<"1-100 ok?: " ;
		cin>>final_score;
	}
	
	GPA=0.2*quiz + 0.3*mid_term + 0.5*final_score ;
	
	cout<<" " <<endl;
	cout<<"GPA = " <<GPA <<endl;
	cout<<" " <<endl;
	
	if (GPA >= 8.5) cout<<"grade A";
	if (GPA >= 7.0 & GPA < 8.5) cout<<"Grade B";
	if (GPA >= 5.5 & GPA < 7.0) cout<<"grade C";
	if (GPA >= 4.0 & GPA < 5.5) cout<<"grade D";
	if (GPA <= 4.0) cout<<"grade E";
		
}
