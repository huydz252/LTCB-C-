#include <iostream>
#include <conio.h>
using namespace std;
int main(){

   char a;
   
   cout << "nhap du lieu can kiem tra: "  ;
   cin>>a;
   if( ((a>='A')&&(a<='Z')) || ((a>='a')&&(a<='z')) )
   cout << "Du lieu ban vua nhap " << a << " la mot ky tu." << endl;
   else if((a>='0') && (a<='9'))
   cout << "Du lieu ban vua nhap " << a << " la mot so." << endl;
   else
   cout << "Du lieu ban vua nhap " << a << " la mot ki tu dac biet" << endl;

}
