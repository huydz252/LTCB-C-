#include <iostream>
using namespace std;
int main(){
	
	float a,b,c;
	
	cout << "nhap canh thu nhat: ";
	cin >>a;
	cout << "nhap canh thu hai: ";
	cin >>b;
	cout << "nhap canh thu ba: ";
	cin >>c;
	
	if (a==0||b==0||c==0) cout<<"day khong phai la tam giac" ;
	if (a+b<=c || a+c<=b || b+c<=a) cout<<"day khong phai la tam giac";
	else if (a==b & b==c) cout<<"day la tam giac deu" ;
	else if (a==b || b==c || a==c) cout<<"day la tam giac can" ;
	else if (a*a+b*b==c*c || a*a+c*c==b*b || b*b+c*c==a*a) cout<<"day la tam giac vuong";
		
}
