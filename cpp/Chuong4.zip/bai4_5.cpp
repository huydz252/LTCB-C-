#include <iostream>
using namespace std;
int main () {
	int a,b,c,d;
	
	cout << "nhap chieu dai HCN thu nhat: ";
	cin >>a;
	cout << "nhap chieu rong HCN thu nhat: ";
	cin >>b; 
	
	cout << "nhap chieu dai HCN thu hai: ";
	cin >>c;
	cout << "nhap chieu rong HCN thu hai: ";
	cin >>d;
	
	if (a*b == c*d) cout << "2 HCN nay co dien tich bang nhau" ;
	if (a*b > c*d) cout << "HCN thu nhat co dien tich lon hon" ;
	if (a*b < c*d) cout << "HCN thu hai co dien tich lon hon" ;
}

