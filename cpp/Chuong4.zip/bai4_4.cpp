#include <iostream>
using namespace std;
int main () {
	float a,b,c;
	cout << "nhap so do goc thu nhat: ";
	cin >>a;
	cout << "nhap so do goc thu hai: ";
	cin >>b;
	cout << "nhap so do goc thu ba: ";
	cin >>c;
	if (a+b+c == 180) cout<<"day la ba goc cua 1 tam giac" ;
	else cout <<"day khong phai la ba goc cua 1 tam giac" ;
}

