#include <iostream>
using namespace std;
int main () {
	
	float a,b;
	
	cout << "nhap so tien (USD) ma ban muon doi : ";
	cin >>a;
	while (a < 0) {
	    cout<<" so tien ban nhap phai lon hon 0 USD:  " ;	 
		cin >> a;  	
    }
    cout<<" " <<endl;
    cout<<"MENU: " <<endl;
    cout<<"1. EURO: 1 USD = 0.94755  EURO " <<endl;
    cout<<"2. Japanese YEN: 1 USD = 149.695 YEN " <<endl;
    cout<<"3. British POUND: 1 USD = 0.81873  POUND " <<endl;
    cout<<"4. Vietnamese VND: 1 USD = 24 455 VND " <<endl;
    
    cout<<" " <<endl;
    
	cout<<"ban muon doi sang loai tien nao? 1,2,3 hay 4? vui long nhap so : " ;
    cin>>b;
    while (b<=0 || b>=5){ 
        cout<<"vui long chon so tu 1 den 4: " ;
        cin>>b;
    }
    
	cout<<" " <<endl;
	
	if (b==1) cout <<a <<" USD bang " <<a*0.94755 <<" EURO" ;
    if (b==2) cout <<a <<" USD bang " <<a*149.695 <<" YEN" ;
    if (b==3) cout <<a <<" USD bang " <<a*0.81873 <<" POUND" ;
    if (b==4) cout <<a <<" USD bang " <<a*24455 <<" VND" ;

}
    
    
