#include <algorithm>
#include <iostream>
using namespace std;
int main() {
    
	long a,b,c,maxx,tb,minn;
    
	cout<<"nhap so nguyen a: " ;
	cin>>a;
	while (a<-999999999 || a>999999999){
		cout<<"nhap a thuoc doan [-999 999 999 , 999 999 999]: " ;
		cin>>a;
	}
	
	cout<<"nhap so nguyen b: " ;
	cin>>b;
	while (b<-999999999 || b>999999999){
		cout<<"nhap b thuoc doan [-999 999 999 , 999 999 999]: " ;
		cin>>b;
	}
	
	cout<<"nhap so nguyen c: " ;
    cin>>c;
    while (c<-999999999 || c>999999999){
		cout<<"nhap c thuoc doan [-999 999 999 , 999 999 999]: " ;
		cin>>c;
	}
       
	maxx = max(a,max(b,c));
    minn = min(a,min(b,c));
    
    if (maxx == a & minn == b) tb = c;
    if (maxx == c & minn == a) tb = b;
    if (maxx == b & minn == c) tb = a;
	
    cout <<minn <<" " <<tb <<" " <<maxx ;
    
    
}
