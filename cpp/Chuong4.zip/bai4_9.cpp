#include <iostream>
using namespace std;
int main () {
	
	int month,year,leap;
	
	cout<<"nhap thang: " ;
	cin>>month;
	while (month <1 || month >12){
		cout<<"lam gi co thang " <<month<<"! nhap lai: " ;
		cin>>month;
	}
	cout<<"nhap nam: " ;
	cin>>year;
	while (year <0 ){
		cout<<"lam gi co nam " <<year<<"! nhap lai: " ;
		cin>>year;
	}
	
	cout<<" " <<endl;
	cout<<"ok! thang " <<month <<" nam " << year <<endl;
	
	if (year % 100 ==0 & year % 400 ==0 ) {
		cout <<"nam "<< year <<" la nam nhuan" <<endl;
		leap=year;
	}
	if (year % 100 !=0 & year % 4 == 0 ) {
		cout <<"nam "<< year <<" la nam nhuan" <<endl;
		leap=year;
    }
	
	cout<<" " <<endl;
		
	if (leap == year) {
	    if (month == 2) cout<<"thang 2 nam " <<year <<" co 29 ngay." ;
        if (month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12) {
			cout<<"thang " <<month <<" co 31 ngay. ";
		}
		if (month==4 || month==6 || month==9 || month==11) {
			cout<<"thang " <<month <<" co 30 ngay. ";
		}
	}
	else {
		if (month == 2) cout<<"thang 2 nam " <<year <<" co 28 ngay." ;
        if (month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12) {
			cout<<"thang " <<month <<" co 31 ngay. ";
		}
		if (month==4 || month==6 || month==9 || month==11) {
			cout<<"thang " <<month <<" co 30 ngay. ";
		}
	}
	
	
    
	
	
	
}
