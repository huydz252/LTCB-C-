#include<iostream>
using namespace std;

const int max_col = 100;	//k dung define thi phai dung const
const int max_row = 100;	//vi kich thuoc mang 2 chieu la hang so


//<ten_mang> [max-hang] [max_cot] ;

void nhapMang(int nhap[max_row][max_col], int r, int c) {
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            cout << "Nhap phan tu thu [" << i << "][" << j << "]: ";
            cin >> nhap[i][j];
        }
    }
}

void xuatMang(int xuat[max_row][max_col], int r, int c) {
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            cout << xuat[i][j] << " ";
        }
        cout << endl;
    }
}

int tongPhanTuMoiDong(int tong[max_row][max_col], int r, int c) {
    for (int i = 0; i < r; i++) {
    	int tongdong = 0;
        for (int j = 0; j < c; j++) {
        	tongdong += tong[i][j];  
			}
		cout<<"tong dong thu " <<i+1 <<" : " <<tongdong <<endl;	   
        }
    }

int TBMoiDong(int tong[max_row][max_col], int r, int c) {
    for (int i = 0; i < r; i++) {
    	double tongdong = 0;
        for (int j = 0; j < c; j++) {
        	tongdong += tong[i][j];  
		}
		double tbdong = tongdong/c;
		cout<<"GT trung binh dong thu " <<i+1 <<" : " <<tbdong <<endl;	   
        }
    }

int tichCacPTMoiCot(int tich[][max_col], int r, int c) {
    for (int i = 0; i < r; i++) {
    	double tichpt = 1;
        for (int j = 0; j < c; j++) {
        	 tichpt *=  tich[i][j];
		}
		cout<<"Tich cac phan tu o dong thu " <<i+1 <<" : " <<tichpt <<endl;	   
        }
    }

int TBMoiCot(int tong[][max_col], int r, int c) {
    for (int i = 0; i < c; i++) {
    	double tongcot = 0;
        for (int j = 0; j < r; j++) {
        	tongcot += tong[j][i];  
		}
		double tbcot = tongcot/r;
		cout<<"GT trung binh cot thu " <<i+1 <<" : " <<tbcot <<endl;	   
        }
    }

int soPTChiaHet4(int chiahet[max_row][max_col] , int r, int c) {
	int dem = 0;
	for(int i = 0; i < r; i++){
		for(int j = 0; j < c; j++){
			if(chiahet[i][j] % 4 == 0){
				dem +=1;
			}
		}
	}
	cout<<"so pt chia het cho 4: " <<dem <<endl;
}

int timPTMax(int ptMax[max_row][max_col], int r, int c){
	int max = ptMax[0][0];
	for(int i = 0; i < r; i++){
		for(int j = 0; j < c; j++){
			if(max < ptMax[i][j]){
				max = ptMax[i][j];
			}
		}
	}
	cout<< "phan tu lon nhat la: " <<max <<endl;
}

int timPTMin(int ptMin[max_row][max_col], int r, int c){
	int min = ptMin[0][0];
	for(int i = 0; i < r; i++){
		for(int j = 0; j < c; j++){
			if(min > ptMin[i][j]){
				min = ptMin[i][j];
			}
		}
	}
	cout<< "phan tu nho nhat la: " <<min <<endl;
}


int main() {
    int arr[max_row][max_col];
    int row, col;
    
    cout << "Nhap so hang: ";
    cin >> row;
    
    cout << "Nhap so cot: ";
    cin >> col;
    
    nhapMang(arr, row, col);
    
	cout << "Mang vua nhap la:" << endl; 
	xuatMang(arr, row, col);
	cout<<"      " <<endl;
	
	tongPhanTuMoiDong(arr, row, col);	
	cout<<"      " <<endl;
	
	TBMoiDong(arr, row, col);
	cout<<"      " <<endl;
	
	tichCacPTMoiCot(arr, row, col);
    cout<<"      " <<endl;
    
    TBMoiCot(arr, row, col);
    cout<<"      " <<endl;
    
	soPTChiaHet4(arr, row, col);
    cout<<"      " <<endl;
    
    timPTMax(arr, row, col);
    cout<<"      " <<endl;
    
    timPTMin(arr, row, col);
    cout<<"      " <<endl;
    
    return 0;
}

