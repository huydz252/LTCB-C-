#include<iostream>
using namespace std;

const int maxLength = 100;

void nhapMang(int arr[], int size) {
	for(int i = 0; i < size; i++) {
		cout<<"Nhap phan tu thu " <<i+1 <<" : ";
		cin>> arr[i];
	}
}

void xuatMang(int arr[], int size) {
	cout<<"Mang ban vua nhap: \n";
	for(int i = 0; i < size; i++) {
		cout<<"arr[" <<i <<"] = " <<arr[i] <<endl;
	}	
}

void tongCacPhanTu (int arr[], int size) {
	int tong = 0;
	for(int i = 0; i < size; i++) {
		tong += arr[i];
	}
	cout<<"Tong cac phan tu cua mang la: " <<tong ;
}

void tichCacPhanTu (int arr[], int size) {
	int tich = 1;
	for(int i = 0; i < size; i++) {
		tich *= arr[i];
	}
	cout<<"Tich cac phan tu cua mang la: " <<tich <<"\n";
}

void giaTriTB(int arr[], int size) {
	int tong = 0;
	for(int i = 0; i < size; i++) {
		tong += arr[i];
	}
	double TB = tong/size;
}

void soPTChiaHet3(int arr[], int size) {
	int dem = 0;
	for(int i = 0; i < size; i++) {
		if(arr[i] % 3 ==0){
			dem +=1;
		}
	}
	cout<<"So phan tu chia het cho 3 : " <<dem <<"\n";
}

void phanTuLonNhat(int arr[], int size) {
	int max = arr[0];
	for(int i = 0; i < size; i++) {
		if(arr[i] > max){
			max = arr[i];
		}
	}
	cout<<"Phan tu lon nhat la : " <<max <<"\n";
}

void phanTuNhoNhat(int arr[], int size) {
	int min = arr[0];
	for(int i = 0; i < size; i++) {
		if(arr[i] < min){
			min = arr[i];
		}
	}
	cout<<"Phan tu nho nhat la : " <<min <<"\n";
}

void sapXepMangTangDan(int arr[], int size) {
	int i,j;
	for(i = 0; i <= size - 2; i++) {
		for(j = i + 1; j < size; j++) {
			if(arr[i] > arr[j]) {
				int t = arr[i];
				arr[i] = arr[j];
				arr[j] = t;
			}
		}
	}
	cout<<"Mang sau khi sap xep tang dan: \n";
	for(int i = 0; i < size; i++) {
		cout<<"arr[" <<i <<"] = " <<arr[i] <<endl;
	}
}

int main() {
	cout <<"Nhap n: ";
	int n;
	cin>>n;
	
	int arr[n];
	
	nhapMang(arr, n);
	cout<<"           " <<endl;
	
	xuatMang(arr, n);
	cout<<"           " <<endl;
	
	tongCacPhanTu(arr, n);
	cout<<"           " <<endl;
	
	giaTriTB(arr, n);
	cout<<"           " <<endl;
	
	soPTChiaHet3(arr, n);
	cout<<"           " <<endl;
	
	phanTuLonNhat(arr, n);
	cout<<"           " <<endl;
	
	phanTuNhoNhat(arr, n);
	cout<<"           " <<endl;
	
	sapXepMangTangDan(arr, n);
	cout<<"          	 " <<endl;
}







