#include <iostream>
using namespace std;
int main () {
    
	int n,a,b;
    
	cout<<"=====MENU=====" <<endl;
    cout<<"1.Addition of two numbers" <<endl;
    cout<<"2.Difference between two numbers" <<endl;
    cout<<"3.Product of two numbers" <<endl;
    cout<<"4.Division of two numbers" <<endl;
    
	cout<<"Enter the number you want to do: " ;
	cin>>n;
	while(n<1||n>4){
		cout<<"Enter the number you want to do(1-4): " <<endl;
	cin>>n;
	}
	
	cout<<"add the first number" <<endl;
	cin>>a;
	cout<<"add second number" <<endl;
	cin>>b;
	
	if (n==1) {
	    cout <<a <<"+" <<b <<"=" <<a+b;	
	}
	if (n==2){
	    cout <<a <<"-" <<b <<"=" <<a-b;
	}
	if (n==3){
	    cout <<a <<"*" <<b <<"=" <<a*b;
	}
	if (n==4){
	    cout <<a <<"*" <<b <<"=" <<a*b;
	}		
}
