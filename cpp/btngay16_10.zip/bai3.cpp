#include <iostream>
using namespace std;
int main () {
	
	char a;
	
	cout<<"nhap ki tu: " ;
	cin>>a;
	
	if (a >= 'a' && a <= 'z'  ||  a >= 'A' && a <= 'Z') {
	    cout<<"ki tu " <<a <<" la 1 chu cai";
    }
	else 
	    cout<<"ki tu " <<a <<" khong phai la 1 chu cai";
return 0;
}
