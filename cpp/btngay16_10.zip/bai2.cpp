#include <iostream>
#include <algorithm>
using namespace std;
int main () {
	
	int a,b,c;
	
	cout<<"add the first number: " ;
	cin>>a;
	cout<<"add second number: " ;
	cin>>b;
	cout<<"add third number: " ;
	cin>>c;
	
	cout<<"The largest of the three numbers is: " <<max(a,(b,c));
}
