#include <iostream>
using namespace std;
int main () {
   
    int n,a,b;
   
    cout<<"=====MENU=====" <<endl;
    cout<<"1.Addition of two numbers" <<endl;
    cout<<"2.Difference between two numbers" <<endl;
    cout<<"3.Product of two numbers" <<endl;
    cout<<"4.Division of two numbers" <<endl;
    
	cout<<"Enter the number you want to do: " ;
	cin>>n;
	while(n<1||n>4){
		cout<<"Enter the number you want to do(1-4): " ;
	cin>>n;
	}
	
	cout<<"add the first number: " ;
	cin>>a;
	cout<<"add second number: " ;
	cin>>b;
	
	switch(n) {
        case 1:
            cout <<a <<"+" <<b <<"=" <<a+b;
            break;
        case 2:
            cout <<a <<"-" <<b <<"=" <<a-b;
            break;
        case 3:
            cout <<a <<"*" <<b <<"=" <<a*b;
            break;
        case 4:
            cout <<a <<"*" <<b <<"=" <<a*b;
            break;

}	
}
