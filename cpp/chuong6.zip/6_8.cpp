#include <iostream>
#include <vector>
using namespace std;

vector<int> oki(int bien) {
    int a;
    vector<int> vec;
    while (bien != 0) {
        a = bien % 10;
        vec.push_back(a); 
        bien = bien / 10;
    }

    int b = vec.size(); 
    for (int i = 0; i < b; i++) {
        for (int j = i + 1; j < b; j++) {
            if (vec[i] > vec[j]) {
                int temp = vec[i];
                vec[i] = vec[j];
                vec[j] = temp;
            }
        }
    }
    return vec; 
}

int main() {
    int a;
    cout << "Input: ";
    cin >> a;
    
    vector<int> resultVector = oki(a); 

    cout << "Output: ";
    if (!resultVector.empty()) { 
        for (size_t i = 0; i < resultVector.size(); ++i) {
            cout << resultVector[i] ;
        }
    } else {
        cout << "Empty vector!"; 
    }
    return 0;
}

