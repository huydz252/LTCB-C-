#include <iostream>
using namespace std;

const double PI = 3.14159;

void calculateArea(double radius, double* result) {
    *result = PI * radius * radius;
}

int main() {
    double radius;
    cout << "Nhap ban kinh cua hinh tron: ";
    cin >> radius;
	
	while (radius <= 0) {
		cout << "Nhap ban kinh cua hinh tron: ";
    	cin >> radius;
	}

    double area;
    calculateArea(radius, &area);

    cout << "Dien tich cua hinh tron la: " << area << endl;
   return 0;
}
