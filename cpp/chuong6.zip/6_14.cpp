#include <iostream>
using namespace std;

int add(int x, int y) {
    return x + y;
}

float add(float a, float b) {
    return a + b;
}

double add(double m, double n) {
    return m + n;
}

int main() {
    
    int x = 25, y = 50;
    float a = 12.65f, b = 116.50f;
    double m = 1234.567, n = 2468.357;

    int sumInt = add(x, y);
    float sumFloat = add(a, b);
    double sumDouble = add(m, n);

    cout << "Sum int: " << sumInt << endl;
    cout << "Sum float: " << sumFloat << endl;
    cout << "Sum double: " << sumDouble << endl;

    return 0;
}

