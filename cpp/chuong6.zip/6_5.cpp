#include <iostream>
using namespace std;
#include <math.h>


int ok(int a,int b){
	return pow(a,b);
}

int main() {
	int x,y;
	cout<<"nhap x: ";
	cin>>x;
	cout<<"nhap y: ";
	cin>>y;
	
	cout<<"f(x) = "<<ok(x,y);
}
