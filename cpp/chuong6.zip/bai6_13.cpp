#include <iostream>
using namespace std;

void swap (int *a, int *b) {
	int temp = *a;
	*a = *b;
	*b = temp;	
}
int main() {
	int a,b;
	cout << "Input A:" ;
	cin>> a;
	cout << "Input B: ";
	cin>> b;
	
	swap(&a,&b);
	
	cout <<"After swap: " <<endl;
	cout <<"A: " <<a <<endl;
	cout <<"B: " <<b;
	
}
