#include <iostream>
using namespace std;

void calculateFactorial(int n, unsigned long long *result) {
    *result = 1;
    for (int i = 1; i <= n; ++i) {
        *result *= i;
    }
}

int main() {
    int number;
    unsigned long long factorial = 1;

    cout << "Enter a number to find its factorial: ";
    cin >> number;

    calculateFactorial(number, &factorial);

    cout << "Factorial of " << number << " is: " << factorial << endl;

    return 0;
}

