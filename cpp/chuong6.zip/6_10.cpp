#include <iostream>
#include <sstream>
using namespace std;

bool isPolydivisible(int num) {
    stringstream ss;
    ss << num; 

    string numStr = ss.str(); 

    int n = numStr.length(); 

    for (int i = 1; i <= n; ++i) {
        string subNum = numStr.substr(0, i);
        
        stringstream converter(subNum); 
        int sub = 0;
        converter >> sub; 
        
        if (sub % i != 0) {
            return false;
        }
    }
    return true;
}

int main() {
    int n;
    cout << "Nhap so n: ";
    cin >> n;

    if (n <= 0) {
        cout << "Vui long nhap mot so nguyen duong." << endl;
        return 1;
    }

    if (isPolydivisible(n)) {
        cout << n << " la so Polydivisible." << endl;
    } else {
        cout << n << " khong phai la so Polydivisible." << endl;
    }

    return 0;
}

