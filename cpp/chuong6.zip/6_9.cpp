#include <iostream>
#include <vector>
using namespace std;

bool checkPrime (int n) {
	if (n<2) return false;
	for (int i = 2; i*i <= n; ++i) {
		if( n%i == 0){
			return false;
		}
	} return true;
}

vector<int> addPrime(int n){
	vector<int> prime;	
	int num = 2;
	while (prime.size() < n) {
		if(checkPrime(num)){
			prime.push_back(num);
		}
		++num;
	}
	return prime;
}

unsigned long long primorial(int n) {
	unsigned long long result = 1;
	vector<int> primes = addPrime(n);
	for(int i = 0; i < primes.size() ; ++i ) {
		result *= primes[i];
	}
	return result;
}

int main() {
    int n;
    cout << "Input n: ";
    cin >> n;
	
    if (n <= 0) {
        cout << "Please enter a positive integer greater than 0." << endl;
        return 1;
    }
    cout << "Primorial<" << n << "> is " << primorial(n) << endl;
    return 0;
}


