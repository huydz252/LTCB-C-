#include <iostream>
using namespace std;

int tongChuSo(int num) {
    int sum = 0;
    while (num != 0) {
        sum += num % 10;
        num /= 10;
    }
    return sum;
}


int timSoLonNhatTongChuSo(int n, int m) {
    if (n > m) {
        return -1; 
    }

    int tongLonNhat = -1;
    int soLonNhat = n;

    for (int i = n; i <= m; i++) {
        int tongHienTai = tongChuSo(i);
        if (tongHienTai >= tongLonNhat) {
            tongLonNhat = tongHienTai;
            soLonNhat = i;
        }
    }
    return soLonNhat;
}

int main() {
    int n , m;
    
    cout<<"Nhap n: " ;
    cin>>n;
    
    cout<<"Nhap m:" ;
    cin>>m;
    
    cout << "Input: n = " << n << ", m = " << m <<endl;
    cout << "Output: " << timSoLonNhatTongChuSo(n, m) << endl;


    return 0;
}
