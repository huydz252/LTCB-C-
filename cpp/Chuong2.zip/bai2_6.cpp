#include <iostream>
using namespace std;

int main()
{	float r;
	float pi=3.14;
	cout<<"nhap ban kinh hinh tron: " ;
	cin>>r;
	
	cout <<"chu vi hinh tron do la: " <<2*pi*r <<endl ;
	cout <<"dien tich hinh tron do la: " <<pi*r*r ;
}
