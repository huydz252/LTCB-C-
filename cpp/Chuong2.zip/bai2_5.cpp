#include <iostream>
using namespace std;

int main()
{   int a,b;
    cout<<"nhap so nguyen thu nhat: " ;
    cin>>a;
    cout<<"nhap so nguyen thu hai: " ;
    cin>>b;
    
    cout <<a <<"+" <<b << "=" <<a+b <<endl;
    cout <<a <<"-" <<b <<"=" <<a-b <<endl ;
    cout <<a <<"*" <<b <<"=" <<a*b <<endl;
    cout <<a <<"/" <<b <<"=" <<a/b <<endl;
    
    

}
