#include <iostream>
using namespace std;

int main () {
   int a,b,swap;
   
   cout<<"nhap so a: " ;
   cin>>a;
   
   cout<<"nhap so b: " ;
   cin>>b;
   
   cout<<"truoc khi hoan doi: " << endl;
   cout<<"a = " << a << ", b = " << b << endl;
   
   swap=a;
   a=b;
   b=swap;
   cout<<"sau khi hoan doi: " << endl;
   cout << "a = " << a << ", b = " << b << endl;

}
