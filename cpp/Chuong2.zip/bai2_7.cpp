#include <iostream>
using namespace std;

int main() {
	float d,r,cv,dt;
	cout<<"nhap chieu dai: " ;
	cin>>d;
	cout<<"nhap chieu rong: " ;
	cin>>r;
	
	cout<<"chu vi hinh chu nhat la: " <<(d+r)*2 <<endl ;
	cout<<"dien tich hinh chu nhat la: " <<d*r <<endl ;
	
	

		
}
