#include <iostream>
using namespace std;

int main() {
	int h,m;
	cout<<"nhap so gio: ";
	cin>>h;
	cout<<"nhap so phut: ";
	cin>>m;
	
	cout <<h <<" gio " <<m <<" phut " <<"bang " <<h*60+m <<" phut." ;
	
}
