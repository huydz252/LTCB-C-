#include <iostream>
using namespace std;

int main() {
	int n,nam,thang,ngay;
	cout<<"nhap so ngay: ";
	cin>>n;
	
	nam=n/365;
	thang=(n-(nam*365))/30 ;
	ngay=n-(nam*365)-(thang*30);
	
	cout <<n <<" ngay bang " <<nam <<" nam, " <<thang <<" thang, " <<ngay <<" ngay" ;
}
