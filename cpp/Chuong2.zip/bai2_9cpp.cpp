#include <iostream>
using namespace std;

int main() {
	float a,b;
	cout<<"nhap so do goc thu nhat: ";
	cin>>a;
	cout<<"nhap so do goc thu hai: ";
	cin>>b;
	
    cout<<"so do goc con lai la: " <<180-a-b;
	
}

